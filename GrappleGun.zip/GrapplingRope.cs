﻿using BS;
using Harmony;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

namespace GrappleGun
{
	public class GrapplingRope : MonoBehaviour
	{
		//Values
		public AnimationCurve effectOverTime;
		public AnimationCurve curve;
		public AnimationCurve curveEffectOverDistance;
		public float curveSize;
		public float scrollSpeed;
		public float segments;
		public float animSpeed;


		//Data
		public LineRenderer lineRenderer;

		public bool holdPosition;

		private Vector3 _start;
		private Vector3 _end;
		private float _time;
		private bool _active;

		public void Init()
		{
			effectOverTime = new AnimationCurve();
			effectOverTime.AddKey(new Keyframe(0.222f, 0.604f));
			effectOverTime.AddKey(new Keyframe(0.987f, -0.760f));
			effectOverTime.AddKey(new Keyframe(2.009f, 0.001f));
			effectOverTime.AddKey(new Keyframe(3.760f, -0.004f));
			effectOverTime.AddKey(new Keyframe(5.405945f, 0f));

			curve = new AnimationCurve();
			curve.AddKey(new Keyframe(0, 1));
			curve.AddKey(new Keyframe(.5f, .5f));
			curve.AddKey(new Keyframe(1.5f, 1.5f));
			curve.AddKey(new Keyframe(2, 1));

			curveEffectOverDistance = new AnimationCurve();
			curveEffectOverDistance.AddKey(new Keyframe(0, 0));
			curveEffectOverDistance.AddKey(new Keyframe(0.3673519f, 1.047478f));
			curveEffectOverDistance.AddKey(new Keyframe(1.461602f, 0.6029292f));
			curveEffectOverDistance.AddKey(new Keyframe(3, 0));

			curveSize = 5;
			scrollSpeed = 5;
			segments = 200;
			animSpeed = 1.5f;

			holdPosition = false;
		}

		public void UpdateGrapple()
		{
			lineRenderer.enabled = _active;
			if (_active)
				ProcessBounce();
		}

		private void ProcessBounce()
		{
			var vectors = new List<Vector3>();

			_time = Mathf.MoveTowards(_time, 1f,
				Mathf.Max(Mathf.Lerp(_time, 1f, animSpeed * Time.deltaTime) - _time, 0.2f * Time.deltaTime));

			vectors.Add(_start);

			var forward = Quaternion.LookRotation(_end - _start);
			var up = forward * Vector3.up;

			for (var i = 1; i < segments + 1; i++)
			{
				var delta = 1f / segments * i;
				var realDelta = delta * curveSize;
				while (realDelta > 1f) realDelta -= 1f;
				var calcTime = realDelta + -scrollSpeed * _time;
				while (calcTime < 0f) calcTime += 1f;

				var defaultPos = GetPos(delta);
				var effect = Eval(effectOverTime, _time) * Eval(curveEffectOverDistance, delta) * Eval(curve, calcTime);

				vectors.Add(defaultPos + up * effect);
			}

			lineRenderer.positionCount = vectors.Count;
			lineRenderer.SetPositions(vectors.ToArray());
		}

		private Vector3 GetPos(float d)
		{
			return Vector3.Lerp(_start, _end, d);
		}

		private static float Eval(AnimationCurve ac, float t)
		{
			return ac.Evaluate(t * ac.keys.Select(k => k.time).Max());
		}

		public void Grapple(Vector3 start, Vector3 end)
		{
			var distance = Vector3.Distance(start, end);
			_active = true;
			_time = 0f;

			_start = start;
			_end = end;
		}

		public void UnGrapple()
		{
			_active = false;
			holdPosition = false;
		}

		public void UpdateStart(Vector3 start)
		{
			_start = start;
		}

		public bool Grappling => _active;
		public void SetEnd(Vector3 value)
		{
			_end = value;
		}
	}
}