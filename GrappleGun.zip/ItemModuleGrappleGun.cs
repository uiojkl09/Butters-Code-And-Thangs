﻿using BS;

namespace GrappleGun
{
	//This creates an item module that can be referenced in the item JSON 
    internal class ItemModuleGrappleGun : ItemModule
    {
		public float maxDistance = 50f;
		public float minDistance = 0.5f;
		public float rotationSmooth = 10;

		//Raycasts
		public float raycastRadius = 0.01f;
		public int raycastCount = 10;

		//Physics
		public float pullForce = 1.5f;
		public float pushForce = 1.5f;
		public float yMultiplier = 1.5f;
		public float minPhysicsDistance = 0;
		public float maxPhysicsDistance = 336;

		public string shootSFX = "GrappleSound";
		
		public override void OnItemLoaded(Item item)
        {
            base.OnItemLoaded(item);
            item.gameObject.AddComponent<ItemGrappleGun>();
        }
    }
}