﻿using BS;
using Harmony;
using System.Collections.Generic;
using UnityEngine;

namespace GrappleGun
{
	public class ItemGrappleGun : MonoBehaviour
	{
		protected Item item;
		private GrapplingRope grapplingRope;
		private Player player = Player.local;
		private Rigidbody grappledObject;
		private GameObject grappledPart;

		private bool IsCreature = false;

		private Transform grappleTip;

		private Vector3 _hit;

		private ItemModuleGrappleGun module;

		public AudioSource shootSFX = null;

		public Rigidbody itemRB = null;

		public bool triggerPulled = false;
		public bool altUsePulled = false;
		private float _holdDistance;

		public ObjectHolder gunHolder = null;

		public Animation animation = null;

		protected void Awake()
		{
			item = this.GetComponent<Item>();
			module = item.data.GetModule<ItemModuleGrappleGun>();

			grapplingRope = new GrapplingRope();
			grapplingRope.lineRenderer = item.GetComponent<LineRenderer>();
			grapplingRope.Init();
			grappleTip = item.transform.Find("Tip");
			altUsePulled = false;

			if (!grapplingRope.lineRenderer)
					Debug.Log("Can't find LineRenderer");

			if (!grappleTip)
				Debug.Log("Can't find grappleTip");


			itemRB = item.GetComponent<Rigidbody>();

			if (module.shootSFX != "None")
			{
				if (item.transform.Find(module.shootSFX))
				{
					if (item.transform.Find(module.shootSFX).gameObject.GetComponentInChildren<AudioSource>())
					{
						shootSFX = item.transform.Find(module.shootSFX).gameObject.GetComponentInChildren<AudioSource>();
					}
					else
					{
						Debug.LogError("GrappleGun error: ShootSFX gameObject doesn't contain an Audio Source");
					}

				}
				else
				{
					Debug.LogError("GrappleGun error: ShootSFX gameObject couldn't be found");
				}

			}

			if (item.GetComponentInChildren<ObjectHolder>())
			{
				gunHolder = item.GetComponentInChildren<ObjectHolder>();
			}

			if (item.GetComponentInChildren<Animation>())
			{
				animation = item.GetComponentInChildren<Animation>();
			}

			item.OnHeldActionEvent += OnHeldAction;
			item.OnUngrabEvent += OnGunUngrab;
		}

		private void FixedUpdate()
		{
			if (triggerPulled && grapplingRope.Grappling)
			{
				float forceMultiplier = 1;
				if (grappledObject != null) {
					//Move _hit to keep up with the objects new location
					_hit = grappledPart.transform.position;
					grapplingRope.SetEnd(_hit);
					if (IsCreature)
						forceMultiplier = 100;
					else
						forceMultiplier = 3;
				}

				var distance = Vector3.Distance(player.transform.position, _hit);
				if (!(distance >= module.minPhysicsDistance) || !(distance <= module.maxPhysicsDistance)) return;
				//Debug.Log("dif=" + Mathf.Abs(_hit.y - player.transform.position.y));
				if (!altUsePulled || (altUsePulled && distance > _holdDistance))
				{
					if (grappledObject != null)
					{
						Vector3 velocity;
						if (IsCreature)
						{
							var heading = player.transform.position - _hit;
							var direction = heading / distance; // This is now the normalized direction.
							velocity = 100 * direction;
							grappledObject.velocity = velocity;
						}
						else
						{
							var heading = player.transform.position - _hit;
							var direction = heading / distance; // This is now the normalized direction.
							velocity = 0.5f * direction;
							grappledObject.velocity += velocity;

						}
					}
					else
					{
						var velocity = module.pullForce * Time.fixedDeltaTime * module.yMultiplier * forceMultiplier * Mathf.Abs(_hit.y - player.transform.position.y) * (_hit - player.transform.position).normalized;
						velocity += module.pullForce * Time.fixedDeltaTime * module.yMultiplier * forceMultiplier * Mathf.Abs(_hit.x - player.transform.position.x) * (_hit - player.transform.position).normalized;
						player.locomotion.rb.velocity += velocity;
					}
				}
			}
		}

		void OnGunUngrab(Handle handle, Interactor interactor, bool throwing)
		{
			if (grapplingRope.Grappling || triggerPulled)
			{
				grapplingRope.UnGrapple();
				triggerPulled = false;
			}
		}

		void OnHeldAction(Interactor interactor, Handle handle, Interactable.Action action)
		{
			if (action == Interactable.Action.UseStart)
				triggerPulled = true;
			if (action == Interactable.Action.UseStop)
				triggerPulled = false;
			if (action == Interactable.Action.AlternateUseStart)
			{
				if (!altUsePulled)
				{
					_holdDistance = Vector3.Distance(player.transform.position, _hit);
					altUsePulled = true;
				}
			}
			if (action == Interactable.Action.AlternateUseStop)
				altUsePulled = false;
		}

		private void LateUpdate()
		{
			RaycastHit hitInfo;

			if (triggerPulled && !grapplingRope.Grappling && RaycastAll(out hitInfo))
			{
				IsCreature = false;
				grappledPart = null;
				//Debug.Log("Grapple((" + grappleTip.position.x + ", " + grappleTip.position.y + ", " + grappleTip.position.z + ") - (" + hitInfo.point.x + ", " + hitInfo.point.y + ", " + hitInfo.point.z + ")");
				if (hitInfo.collider.attachedRigidbody != null)
				{
					Debug.Log("Rigidbody GameObject name (only for Gameobjects with rigidbody): " + hitInfo.collider.attachedRigidbody.gameObject.name);
					if (hitInfo.collider.attachedRigidbody.gameObject.name == "UMANPC_Human")
					{
						grappledObject = hitInfo.rigidbody;
						var target = hitInfo.collider.transform.root.GetComponent<Creature>();
						if (target != null && target != Creature.player)
						{
							//target.UnequipWeapons();
							if (target.state != Creature.State.Dead)
								target.ragdoll.SetState(Creature.State.Destabilized);

							grappledPart = target.body.headBone.gameObject;
							grappledObject = target.locomotion.rb;
						}
						IsCreature = true;
					}
					else
						grappledObject = hitInfo.rigidbody;
				}
				else
				{
					if (hitInfo.collider.GetComponentInParent<GameObject>() != null)
					{
						//Debug.Log("Name of the parent GameObject: " + hitInfo.collider.GetComponentInParent<GameObject>().name);
						grappledObject = hitInfo.rigidbody;
					}
					else
					{
						//Debug.Log("This collider has no parent");
						grappledObject = hitInfo.rigidbody;
					}
				}
				if (grappledObject != null && grappledPart == null)
					grappledPart = hitInfo.transform.gameObject;

				grapplingRope.Grapple(grappleTip.position, hitInfo.point);
				_hit = hitInfo.point;
				if (shootSFX)
					shootSFX.Play();
			}

			if (!triggerPulled)
			{
				grapplingRope.UnGrapple();
			}

			if (triggerPulled && grapplingRope.Grappling)
			{
				grapplingRope.holdPosition = altUsePulled;
				grapplingRope.UpdateStart(grappleTip.position);
			}

			grapplingRope.UpdateGrapple();
		}

		private bool RaycastAll(out RaycastHit hit)
		{
			var divided = module.raycastRadius / 2f;
			var possible = new List<RaycastHit>();
			var cam = grappleTip.transform;

			RaycastHit hitInfo;
			if (Physics.Raycast(cam.position, cam.forward, out hitInfo, module.maxDistance))
			{
				var distance = Vector3.Distance(cam.position, hitInfo.point);
				if (distance >= module.minDistance && distance <= module.maxDistance)
					possible.Add(hitInfo);
			}

			var arr = possible.ToArray();
			possible = null;

			if (arr.Length > 0)
			{
				var closest = new RaycastHit();
				var distance = 0f;
				var set = false;

				foreach (var thisHit in arr)
				{
					var hitDistance = Vector3.Distance(cam.position, thisHit.point);

					if (!set)
					{
						set = true;
						distance = hitDistance;
						closest = thisHit;
					}
					else if (hitDistance < distance)
					{
						distance = hitDistance;
						closest = thisHit;
					}
				}

				hit = closest;
				return true;
			}

			hit = new RaycastHit();
			return false;
		}
	}
}
 
 